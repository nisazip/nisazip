package kh.manager.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kh.manager.model.service.ManagerService;

@WebServlet("/deleteRoom.mg")
public class DeleteRoomServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public DeleteRoomServlet() { }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String rno = request.getParameter("roomNo");
		
		int result = new ManagerService().deleteRoom(rno);
		
		String page="";
		
		if(result >0){
			page="/roomList.mg";
			request.getRequestDispatcher(page).forward(request, response);
		}else{
			System.out.println("숙소 삭제 실패");
			page="views/common/errorPage";
			request.getRequestDispatcher(page).forward(request, response);
		}
			
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
