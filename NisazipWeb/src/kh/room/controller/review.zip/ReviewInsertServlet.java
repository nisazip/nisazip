package kh.room.controller.review;

import java.io.IOException;
import java.sql.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kh.room.model.service.reviewService;
import kh.room.model.vo.review;

/**
 * Servlet implementation class ReviewInsertServlet
 */
@WebServlet("/reviewInsert.re")
public class ReviewInsertServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ReviewInsertServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String user_id =request.getParameter("user_id");
		String hosting_id =request.getParameter("hosting_id");
		String re_content = request.getParameter("re_content");
		float re_score =Float.parseFloat( request.getParameter("re_score"));
		
		int result = 0;
		//new ReviewService().checkInfo(hosting_id,user_id) >0 
		if(true) { 

		review re = new review();
		re.setHosting_id(hosting_id);
		re.setRe_content(re_content);
		re.setUser_id(user_id);
		re.setRe_score(re_score);
		
		result= new reviewService().reviewInsert(re);
		System.out.println(re);
		}else{
			result =-1;
		}
		
		response.getWriter().print(result);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
